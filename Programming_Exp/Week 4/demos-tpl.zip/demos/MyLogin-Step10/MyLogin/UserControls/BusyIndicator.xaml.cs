﻿using System.Windows.Controls;

namespace MyLogin.UserControls
{
    public partial class BusyIndicator : UserControl
    {
        public BusyIndicator()
        {
            InitializeComponent();
        }
    }
}
