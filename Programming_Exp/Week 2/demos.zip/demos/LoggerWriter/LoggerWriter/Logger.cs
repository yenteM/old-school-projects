﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoggerWriter
{
    public class Logger
    {
        public void WriteMessage(string message)
        {
            Console.WriteLine(message);
        }
    }
}
