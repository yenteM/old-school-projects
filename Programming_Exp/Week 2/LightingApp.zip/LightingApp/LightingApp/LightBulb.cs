﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LightingApp
{
    public class LightBulb
    {
        public bool IsOn { get; set; }
        public string Color { get; set; }

    }
}
